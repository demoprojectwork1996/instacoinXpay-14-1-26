import React,{useState} from "react";
import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";
import "./LandingPage.css"
import coinsImg1 from "../assets/Cam1.png";
import coinsImg2 from "../assets/Cam2.png";
import coinsImg3 from "../assets/Cam3.png";
import BuyCrypto from "../assets/BuyCryptocurrency.png";
import globe from "../assets/globe.png";
import elon from "../assets/elon.png";
import LearnCrypto from "../assets/LearnCrypto.png";
import { 
  TrendingUp, 
  TrendingDown, 
  ChevronDown, 
  ChevronUp,
  BarChart3,
  Filter,
  MoreVertical,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
 import { Shield, Lock, Insurance, Users, DollarSign, Star, CheckCircle, Quote } from 'lucide-react';
export default function App() {
     const navigate = useNavigate();
     const [showAll, setShowAll] = useState(false);
     const cryptoData = [
    {
      id: 1,
      rank: 1,
      name: "Bitcoin",
      symbol: "BTC",
      price: "$50,964.19",
      change24h: "+4.72%",
      change7d: "+8.57%",
      marketCap: "$1,056,191,721,301",
      trend: "up",
      sparkline: [0, 4, 2, 6, 8, 10, 12, 15, 12, 10, 13, 15],
      logoColor: "#F7931A"
    },
    {
      id: 2,
      rank: 2,
      name: "Ethereum",
      symbol: "ETH",
      price: "$2,890.45",
      change24h: "-3.45%",
      change7d: "-2.15%",
      marketCap: "$347,625,891,234",
      trend: "down",
      sparkline: [15, 13, 12, 10, 8, 10, 12, 11, 10, 8, 9, 7],
      logoColor: "#627EEA"
    },
    {
      id: 3,
      rank: 3,
      name: "Binance Coin",
      symbol: "BNB",
      price: "$325.67",
      change24h: "+1.85%",
      change7d: "+5.42%",
      marketCap: "$52,349,178,912",
      trend: "up",
      sparkline: [0, 2, 4, 3, 5, 7, 9, 8, 10, 12, 11, 13],
      logoColor: "#F0B90B"
    },
    {
      id: 4,
      rank: 4,
      name: "Tether",
      symbol: "USDT",
      price: "$1.00",
      change24h: "-0.02%",
      change7d: "+0.01%",
      marketCap: "$95,123,456,789",
      trend: "mixed",
      sparkline: [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
      logoColor: "#26A17B"
    },
    {
      id: 5,
      rank: 5,
      name: "Cardano",
      symbol: "ADA",
      price: "$0.52",
      change24h: "+2.34%",
      change7d: "+12.67%",
      marketCap: "$18,456,123,456",
      trend: "up",
      sparkline: [0, 1, 3, 2, 4, 6, 8, 10, 12, 14, 16, 18],
      logoColor: "#0033AD"
    },
    {
      id: 6,
      rank: 6,
      name: "Quarkchain",
      symbol: "QKC",
      price: "$0.0123",
      change24h: "+45.67%",
      change7d: "+89.12%",
      marketCap: "$856,123,456",
      trend: "up",
      sparkline: [0, 10, 20, 15, 25, 30, 40, 35, 45, 50, 60, 70],
      logoColor: "#32D49D"
    },
    {
      id: 7,
      rank: 7,
      name: "Solana",
      symbol: "SOL",
      price: "$102.45",
      change24h: "+8.92%",
      change7d: "+23.45%",
      marketCap: "$42,123,456,789",
      trend: "up",
      sparkline: [0, 2, 5, 8, 12, 15, 18, 22, 25, 28, 30, 35],
      logoColor: "#00FFA3"
    },
    {
      id: 8,
      rank: 8,
      name: "XRP",
      symbol: "XRP",
      price: "$0.55",
      change24h: "-1.23%",
      change7d: "+3.45%",
      marketCap: "$29,456,789,123",
      trend: "mixed",
      sparkline: [0, 1, 2, 1, 3, 2, 4, 3, 5, 4, 6, 5],
      logoColor: "#23292F"
    },
    {
      id: 9,
      rank: 9,
      name: "Polkadot",
      symbol: "DOT",
      price: "$7.89",
      change24h: "+3.21%",
      change7d: "+15.67%",
      marketCap: "$10,234,567,890",
      trend: "up",
      sparkline: [0, 2, 3, 5, 6, 8, 10, 12, 14, 16, 18, 20],
      logoColor: "#E6007A"
    },
    {
      id: 10,
      rank: 10,
      name: "Dogecoin",
      symbol: "DOGE",
      price: "$0.085",
      change24h: "-5.67%",
      change7d: "-12.34%",
      marketCap: "$12,345,678,901",
      trend: "down",
      sparkline: [20, 18, 16, 14, 12, 10, 8, 6, 4, 2, 1, 0],
      logoColor: "#C2A633"
    }
  ];

  const displayedData = showAll ? cryptoData : cryptoData.slice(0, 6);

  const getSparklinePath = (data) => {
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min;
    
    const points = data.map((value, index) => {
      const x = (index / (data.length - 1)) * 100;
      const y = 100 - ((value - min) / range) * 100;
      return `${x},${y}`;
    });
    
    return `M ${points.join(' L ')}`;
  };

  const getTrendColor = (trend) => {
    switch(trend) {
      case 'up': return '#10B981';
      case 'down': return '#EF4444';
      default: return '#6B7280';
    }
  };
  return (
    <div>
      {/* NAVBAR */}
      <div className="nav">
        <div className="logo">
             <img src={logo} alt="InstaCoinXPay Logo" />
        </div>
      
        <div className="auth">
          <button className="btn-outline" onClick={() => navigate("/login")}>Login</button>
          <button className="btn-signup" onClick={() => navigate("/getstarted")}>Signup</button>
        </div>
      </div>

      {/* HERO */}
      <section className="hero" >
        <div className="hero-left">
          <p className="tag">Sign Up Now!</p>
          <h1>
            Buy, Sell & Swap <br />
            <span>Cryptocurrency</span> <br />in Minutes
          </h1>
          <p className="sub">
            Trade Bitcoin, Ethereum, Binance and top altcoins on one platform.
          </p>
          <div className="email-box">
            <input placeholder="Enter your email" />
            <button className="btn-signup">Get Started</button>
          </div>
        </div>
  <div className="crypto-container">
      <img
        src={coinsImg3}
        alt="BNB Coin"
        className="coin bnb-coin-1"
      />

      <img
        src={coinsImg2}
        alt="ETH Coin"
        className="coin eth-coin-2"
      />

      <img
        src={coinsImg1}
        alt="BNB Coin"
        className="coin btc-coin-3"
      />
    </div>
      </section>

      {/* EXCHANGES */}
      <section className="exchanges">
       <img src={BuyCrypto} alt="Buy Cryptocurrency" />
      </section>

      {/* MARKET TABLE */}
      <section className="market">
        <div className="market-trend-container">
      <div className="market-trend-header">
        <div className="header-left">
          <h1>Trending in Market</h1>
          <h2>Ranking Cryptocurrency</h2>
        </div>
        <div className="header-right">
          <button className="filter-btn">
            <Filter size={18} />
            Filter
          </button>
          <button className="view-chart-btn">
            <BarChart3 size={18} />
            View Chart
          </button>
        </div>
      </div>

      <div className="market-table-container">
        <div className="table-wrapper">
          <table className="market-table">
            <thead>
              <tr>
                <th className="rank-header">#</th>
                <th className="name-header">Name</th>
                <th className="price-header">Price</th>
                <th className="change-header">24h %</th>
                <th className="change-header">7d %</th>
                <th className="market-cap-header">Market Cap</th>
                <th className="chart-header">Last 7 Days</th>
                <th className="action-header"></th>
              </tr>
            </thead>
            <tbody>
              {displayedData.map((crypto) => (
                <tr key={crypto.id} className="crypto-row">
                  <td className="rank-cell">
                    <div className="rank-number">{crypto.rank}</div>
                  </td>
                  <td className="name-cell">
                    <div className="crypto-info">
                      <div 
                        className="crypto-logo"
                        style={{ backgroundColor: crypto.logoColor }}
                      >
                        {crypto.symbol.charAt(0)}
                      </div>
                      <div className="crypto-details">
                        <div className="crypto-name">{crypto.name}</div>
                        <div className="crypto-symbol">{crypto.symbol}</div>
                      </div>
                      {crypto.rank === 6 && (
                        <div className="buy-tag">
                          <span>Buy</span>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="price-cell">
                    <div className="price-amount">{crypto.price}</div>
                  </td>
                  <td className="change-cell">
                    <div 
                      className={`change-badge ${crypto.change24h.startsWith('+') ? 'positive' : 'negative'}`}
                    >
                      {crypto.change24h.startsWith('+') ? (
                        <ArrowUpRight size={14} />
                      ) : (
                        <ArrowDownRight size={14} />
                      )}
                      {crypto.change24h}
                    </div>
                  </td>
                  <td className="change-cell">
                    <div 
                      className={`change-badge ${crypto.change7d.startsWith('+') ? 'positive' : 'negative'}`}
                    >
                      {crypto.change7d.startsWith('+') ? (
                        <ArrowUpRight size={14} />
                      ) : (
                        <ArrowDownRight size={14} />
                      )}
                      {crypto.change7d}
                    </div>
                  </td>
                  <td className="market-cap-cell">
                    {crypto.marketCap}
                  </td>
                  <td className="chart-cell">
                    <div className="sparkline-container">
                      <svg 
                        className="sparkline" 
                        viewBox="0 0 100 100" 
                        preserveAspectRatio="none"
                      >
                        <path 
                          d={getSparklinePath(crypto.sparkline)}
                          fill="none"
                          stroke={getTrendColor(crypto.trend)}
                          strokeWidth="2"
                        />
                      </svg>
                    </div>
                  </td>
                  <td className="action-cell">
                    <button className="more-options-btn">
                      <MoreVertical size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="show-more-container">
          <button 
            className="show-more-btn"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? (
              <>
                Show Less
                <ChevronUp size={16} />
              </>
            ) : (
              <>
                Show More
                <ChevronDown size={16} />
              </>
            )}
          </button>
        </div>
      </div>

      <div className="market-stats">
        <div className="stats-card">
          <div className="stats-icon" style={{ backgroundColor: 'rgba(16, 185, 129, 0.1)' }}>
            <TrendingUp size={24} color="#10B981" />
          </div>
          <div className="stats-content">
            <div className="stats-label">Top Gainer (24h)</div>
            <div className="stats-value">Quarkchain (QKC)</div>
            <div className="stats-change positive">+45.67%</div>
          </div>
        </div>
        
        <div className="stats-card">
          <div className="stats-icon" style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}>
            <TrendingDown size={24} color="#EF4444" />
          </div>
          <div className="stats-content">
            <div className="stats-label">Top Loser (24h)</div>
            <div className="stats-value">Dogecoin (DOGE)</div>
            <div className="stats-change negative">-5.67%</div>
          </div>
        </div>
        
        <div className="stats-card">
          <div className="stats-icon" style={{ backgroundColor: 'rgba(59, 130, 246, 0.1)' }}>
            <BarChart3 size={24} color="#3B82F6" />
          </div>
          <div className="stats-content">
            <div className="stats-label">Total Market Cap</div>
            <div className="stats-value">$2.1T</div>
            <div className="stats-change positive">+3.2%</div>
          </div>
        </div>
      </div>
    </div>
      </section>

    <section className="trusted-wrapper">
      
      {/* TOP SECTION */}
      <div className="trusted-top">
        <div className="trusted-cards">
          <div className="info-card-1">
            <h4>Secure Storage</h4>
            <p>Your assets are secured with advanced protection.</p>
            <span>Learn More →</span>
          
          </div>
   <div className="info-card-1 active">
            <h4>Secure Storage</h4>
            <p>We securely store your crypto to help keep your assets safe.</p>
            <span>Learn More →</span>
          </div>
          
        </div>

        <div className="trusted-text">
          <h2>
            The Most Trusted <br />
            <span>Cryptocurrency</span> Platform
          </h2>
          <p>Explore the top reasons customers trust Demo.</p>
        </div>
        <div className="info-card-1">
            <h4>Protected by Insurance</h4>
            <p>Your funds come with an extra layer of protection.</p>
            <span>Learn More →</span>
          </div>
      </div>

      {/* MIDDLE SECTION */}
      <div className="trusted-middle">
        <div className="features">
          <h3>
            Some <span>Key Features</span> <br /> Of Demo ✨
          </h3>

          <p className="desc">
            Here are few reasons why you should choose Demo.
          </p>

          <div className="stats">
            <div>
              <h4>141,000+</h4>
              <p>Registered Users</p>
            </div>
            <div>
              <h4>$280M+</h4>
              <p>Airdrops Given</p>
            </div>
            <div>
              <h4>$38M+</h4>
              <p>Monthly Withdrawals</p>
            </div>
          </div>
        </div>

        <div className="globe">
          <img src={globe} alt="Globe" />
        </div>
      </div>

      {/* BOTTOM SECTION */}
      <div className="trusted-bottom">
        <div className="testimonial-img">
          <img src={elon} alt="Elon Musk" />
        </div>

        <div className="testimonial-text">
          <p className="quote">
            "It is inevitable — crypto will be the future currency of Earth."
          </p>

          <h5>Elon Musk</h5>
          <span>
            Businessman and former Senior Advisor <br />
            to the President of the United States
          </span>
        </div>
      </div>
    </section>
<section className="how-wrapper">
      {/* Heading */}
      <div className="how-header">
        <h2>How It Works</h2>
        <p>Crypters supports a variety of the most popular digital currencies</p>
      </div>

      {/* Title + Button */}
      <div className="how-title">
        <div>
          <h3>
            We Will <span>Help You to Start</span> <br />
            Crypto Investment ✨
          </h3>
        </div>
        <button className="btn-primary" onClick={() => navigate("/getstarted")}>Get Started</button>
      </div>

      {/* Cards */}
      <div className="how-cards">
        {/* Card 1 */}
        <div className="how-card active">
          <div className="step">
            <span className="icon">👤</span>
            <span className="number">1</span>
          </div>
          <h4>Create an Account</h4>
          <p>
            Set up a secure account to begin using our platform and keep your
            information protected.
          </p>
          <button className="btn-outline" onClick={() => navigate("/getstarted")}>Create New Account</button>
        </div>

        {/* Card 2 */}
        <div className="how-card">
          <div className="step">
            <span className="icon">🏦</span>
            <span className="number">2</span>
          </div>
          <h4>Link Your Bank Account</h4>
          <p>
            Securely link your bank account to enable fiat deposits and
            withdrawals for your crypto trades.
          </p>
        </div>

        {/* Card 3 */}
        <div className="how-card">
          <div className="step">
            <span className="icon">📈</span>
            <span className="number">3</span>
          </div>
          <h4>Start Buying & Selling</h4>
          <p>
            Start building your crypto portfolio with fast, intuitive, and
            secure transactions.
          </p>
        </div>
      </div>
    </section>
      {/* BLOG */}
      <section className="blog">
       <img src={LearnCrypto} alt="Learn Crypto" />
      </section>

    <section className="cta-section">
        <div className="cta-left">
          <h2>
            Let's Start Your <br />
            <span>Crypto Investment</span> Now!
          </h2>

          <div className="cta-buttons">
            <button className="btn-primary" onClick={() => navigate("/getstarted")}>Let's Begin</button>
            <button className="btn-outline">Explore More</button>
          </div>
        </div>

        <div className="cta-right">
          <img src={globe} alt="Crypto Globe" />
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <div className="footer-top">
          {/* Logo + Apps */}
          <div className="footer-col">
            <img src={logo} alt="Logo" className="footer-logo" />
            <div className="store-buttons">
              {/* <img src={appstore} alt="App Store" />
              <img src={playstore} alt="Google Play" /> */}
            </div>
          </div>

          {/* Telegram */}
          <div className="footer-col center">
            <h4>Join Our Telegram Channel</h4>
            <button className="btn-telegram">Join</button>
          </div>

          {/* Contact */}
          <div className="footer-col right">
            <h4>Contact</h4>
            <p>info@goodcoin.com</p>
            <p>Tel: +1 (872) 282-4046</p>
            <p>
              124 Finchley Road, London, <br />
              United Kingdom, NW3 5JS
            </p>
          </div>
        </div>

        <div className="footer-bottom">
          <p>Copyright © ProigmaTemplates.com. All Rights Reserved.</p>
          <p>Privacy Policy | Terms & Conditions</p>
        </div>
      </footer>

      {/* STYLES */}
      <style>{`
        .nav{display:flex;justify-content:space-between;align-items:center;padding:20px 60px}
        .nav-link{background:none;border:none;color:#0f172a;cursor:pointer;font-size:16px;margin:0 12px;padding:0}
        .nav-link:hover{color:#2563eb}
     
        .btn:hover{background:#1d4ed8}
        .btn-outline{border:1px solid #2563eb;background:transparent;color:#2563eb;padding:10px 18px;border-radius:20px;cursor:pointer}
        .btn-outline:hover{background:#2563eb;color:#fff}
        .hero{display:flex;justify-content:space-between;padding:80px 60px;background:#f8fbff}
        .hero h1 span{color:#38bdf8}
        .email-box{display:flex;gap:10px;margin-top:20px}
        .email-box input{padding:12px;border-radius:20px;border:1px solid #cbd5e1;width:260px}
        .hero-right{font-size:120px}
        .exchanges{display:flex;justify-content:space-around;padding:30px 0;color:#64748b}
        .market{padding:60px}
        table{width:100%;border-collapse:collapse}
        th,td{padding:14px;border-bottom:1px solid #e2e8f0}
        .up{color:green}
        .features{background:#eaf6ff;padding:60px;text-align:center}
        .stats{display:flex;justify-content:center;gap:60px}
        .how{padding:60px;text-align:center}
        .steps{display:flex;gap:30px;justify-content:center}
        .card{padding:30px;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.05)}
        .blog{padding:60px}
        .blog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
        .blog-card{padding:40px;border-radius:16px;background:#f1f5f9}
        .cta{padding:80px;text-align:center;background:#f8fbff}
        footer{text-align:center;padding:30px;background:#0f172a;color:#fff}
      `}</style>
    </div>
  );
}