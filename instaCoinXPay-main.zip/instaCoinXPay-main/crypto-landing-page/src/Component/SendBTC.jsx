import React from "react";
import "./SendBTC.css";
import logo from "../assets/logo.png";

const SendBTC = () => {
  return (
    <div className="btc-send-page">
      {/* Logo */}
      <div className="btc-send-logo">
        <img src={logo} alt="btc-send-logo" />
      </div>

      {/* Card */}
      <div className="btc-send-card">
        <h2 className="btc-title">SEND BTC</h2>

        {/* Address */}
        <div className="btc-form-group">
          <label>Address</label>
          <input type="text" placeholder="Long press to paste" />
        </div>

        {/* Network */}
        <div className="btc-form-group">
          <label>Network</label>
          <input type="text" value="BTC" readOnly />
        </div>

        {/* Withdrawal */}
        <div className="btc-form-group">
          <label>Withdrawal Amount</label>
          <div className="btc-amount-box">
            <input type="number" placeholder="0" />
            <div className="btc-amount-right">
              <span>USD</span>
              <span className="btc-max">MAX</span>
            </div>
          </div>
        </div>

        {/* Available */}
        <div className="btc-available">
          <span>Available</span>
          <span>$5713.00 in USD</span>
        </div>

        {/* Info */}
        <p className="btc-info">
          * Do not withdraw directly to a crowdfund or ICO. We will not credit
          your account with tokens from that sale.
        </p>

        {/* Bottom */}
        <div className="btc-bottom">
          <div className="btc-receive">
            <strong>Receive Amount</strong>
            <p>$0.00000 in USD</p>
            <small>Network Fee 0 USD</small>
          </div>

          <button className="btc-withdraw-btn">Withdraw</button>
        </div>
      </div>
    </div>
  );
};

export default SendBTC;
