import { useState } from "react";

export default function CardActivation() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const [card, setCard] = useState({
    name: "",
    number: "",
    expiry: "",
    cvv: "",
    status: "PENDING"
  });

  const submitEmail = () => {
    if (!email) return alert("Enter email address");
    setSubmitted(true);
  };

  const updateField = (field, value) => {
    setCard({ ...card, [field]: value });
  };

  const setStatus = (status) => {
    setCard({ ...card, status });
  };

  return (
    <div style={styles.page}>
      {/* Email Section */}
      <label style={styles.label}>Enter Email address:</label>
      <input
        style={styles.input}
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <button style={styles.submitBtn} onClick={submitEmail}>
        Submit
      </button>

      {/* Card Section */}
      {submitted && (
        <>
          {/* Card Name Dropdown */}
          <div style={{ marginTop: "30px" }}>
            <label style={styles.label}>Select Card Type</label>
            <select
              style={styles.input}
              value={card.name}
              onChange={(e) => updateField("name", e.target.value)}
            >
              <option value="">Select Card</option>
              <option>Merchant Visa Card</option>
              <option>Classic Visa Card</option>
              <option>Prime Visa Card</option>
              <option>Platinum Visa Card</option>
              <option>World Elite Visa Card</option>
            </select>
          </div>

          <h3 style={{ marginTop: "20px" }}>
            {card.name || "Visa Card Details"}
          </h3>

          {/* Row 1 */}
          <div style={styles.row}>
            <input
              style={styles.smallInput}
              placeholder="card number"
              value={card.number}
              onChange={(e) => updateField("number", e.target.value)}
            />
            <input
              style={styles.smallInput}
              placeholder="Expiry date"
              value={card.expiry}
              onChange={(e) => updateField("expiry", e.target.value)}
            />
            <input
              style={styles.smallInput}
              placeholder="CVV"
              value={card.cvv}
              onChange={(e) => updateField("cvv", e.target.value)}
            />
            <button style={styles.grayBtn}>Update</button>
          </div>

          {/* Row 2 */}
          <div style={styles.row}>
            <button
              style={styles.grayBtn}
              onClick={() => setStatus("APPROVED")}
            >
              Approve
            </button>
            <button
              style={styles.grayBtn}
              onClick={() => setStatus("PENDING")}
            >
              Pending
            </button>
            <button
              style={styles.grayBtn}
              onClick={() => setStatus("DEACTIVATED")}
            >
              Deactivate
            </button>
            <button style={styles.grayBtn}>Update</button>
          </div>

          {/* Status Display */}
          <p style={{ marginTop: "15px" }}>
            <b>Current Status:</b>{" "}
            <span
              style={{
                color:
                  card.status === "APPROVED"
                    ? "green"
                    : card.status === "PENDING"
                    ? "orange"
                    : "red"
              }}
            >
              {card.status}
            </span>
          </p>
        </>
      )}
    </div>
  );
}

const styles = {
  page: {
    padding: "40px",
    maxWidth: "900px"
  },
  label: {
    fontWeight: "bold"
  },
  input: {
    width: "450px",
    padding: "12px",
    margin: "10px 0",
    borderRadius: "8px",
    border: "none",
    background: "#b9b9bd"
  },
  submitBtn: {
    display: "block",
    width: "450px",
    padding: "12px",
    background: "#2f5197",
    color: "#fff",
    border: "none",
    borderRadius: "25px",
    cursor: "pointer",
    fontSize: "16px"
  },
  row: {
    display: "flex",
    gap: "20px",
    marginTop: "15px"
  },
  smallInput: {
    width: "220px",
    padding: "12px",
    borderRadius: "8px",
    border: "none",
    background: "#b9b9bd"
  },
  grayBtn: {
    width: "200px",
    padding: "12px",
    borderRadius: "10px",
    border: "none",
    background: "#b9b9bd",
    cursor: "pointer",
    fontWeight: "bold"
  }
};