const express = require("express");
const router = express.Router();
const DebitCardApplication = require("../models/DebitCardApplication");

// ✅ APPLY DEBIT CARD
router.post("/apply", async (req, res) => {
  try {
    const application = new DebitCardApplication(req.body);
    await application.save();

    res.status(201).json({
      success: true,
      message: "Debit card application submitted",
      data: application,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Something went wrong",
    });
  }
});

module.exports = router;
