const mongoose = require("mongoose");

const DebitCardApplicationSchema = new mongoose.Schema(
  {
    cardType: {
      type: String,
      required: true,
    },
    fullName: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    whatsapp: String,
    address: String,
    zipcode: String,
    country: String,
    status: {
      type: String,
      default: "PENDING",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model(
  "DebitCardApplication",
  DebitCardApplicationSchema
);
