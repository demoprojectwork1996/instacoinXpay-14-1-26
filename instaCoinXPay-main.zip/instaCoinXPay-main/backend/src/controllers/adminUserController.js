const User = require('../models/User');
const csv = require('csv-parser');
const xlsx = require('xlsx');
const { Readable } = require('stream');
const bcrypt = require('bcryptjs');

/* CREATE SINGLE USER */
exports.createSingleUser = async (req, res) => {
  try {
    const { name, email, password, country, referral } = req.body;

    if (!name || !email || !password || !country) {
      return res.status(400).json({ 
        success: false, 
        error: 'Required fields missing: Name, Email, Password, Country' 
      });
    }

    // Check if user already exists
    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) {
      return res.status(400).json({ 
        success: false, 
        error: 'User already exists with this email' 
      });
    }

    // Generate referral code for new user
    const referralCode = 'REF' + Math.random().toString(36).substr(2, 9).toUpperCase();

    // Create user
    const user = await User.create({
      fullName: name,
      email: email.toLowerCase(),
      password, // Will be hashed by pre-save middleware
      country,
      referralCode,
      referredBy: referral || null,
      isVerified: true,
    });

    res.status(201).json({ 
      success: true, 
      message: 'User created successfully', 
      data: user 
    });

  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Server error creating user' 
    });
  }
};

/* CREATE USERS FROM FILE (CSV or Excel) */
exports.createUsersFromFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        error: 'File is required' 
      });
    }

    const file = req.file;
    const fileExtension = file.originalname.split('.').pop().toLowerCase();
    let usersData = [];

    // Parse CSV file
    if (fileExtension === 'csv') {
      usersData = await parseCSV(file.buffer);
    }
    // Parse Excel file
    else if (fileExtension === 'xlsx' || fileExtension === 'xls') {
      usersData = await parseExcel(file.buffer);
    }
    else {
      return res.status(400).json({ 
        success: false, 
        error: 'Unsupported file format. Please upload CSV or Excel file.' 
      });
    }

    if (usersData.length === 0) {
      return res.status(400).json({ 
        success: false, 
        error: 'No valid user data found in the file' 
      });
    }

    // Process users
    const results = {
      total: usersData.length,
      created: 0,
      failed: 0,
      errors: []
    };

    for (const row of usersData) {
      try {
        const { Name, Email, Country, ReferralCode, Password } = row;

        // Validate required fields
        if (!Name || !Email || !Country) {
          results.failed++;
          results.errors.push(`Row skipped: Missing required fields for ${Email || 'unknown'}`);
          continue;
        }

        // Check if user already exists
        const existingUser = await User.findOne({ email: Email.toLowerCase() });
        if (existingUser) {
          results.failed++;
          results.errors.push(`User already exists: ${Email}`);
          continue;
        }

        // Generate referral code if not provided
        const referralCode = row.ReferralCode || 'REF' + Math.random().toString(36).substr(2, 9).toUpperCase();
        
        // Generate password if not provided
        const password = Password || await generateDefaultPassword();

        // Create user
        await User.create({
          fullName: Name,
          email: Email.toLowerCase(),
          password,
          country: Country,
          referralCode,
          referredBy: ReferralCode || null,
          isVerified: true,
        });

        results.created++;
      } catch (error) {
        results.failed++;
        results.errors.push(`Error processing row: ${error.message}`);
      }
    }

    res.status(201).json({
      success: true,
      message: `${results.created} users created successfully, ${results.failed} failed`,
      ...results
    });

  } catch (error) {
    console.error('Error processing file:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Error processing file: ' + error.message 
    });
  }
};

/* PARSE CSV FILE */
const parseCSV = (buffer) => {
  return new Promise((resolve, reject) => {
    const results = [];
    const stream = Readable.from(buffer.toString());
    
    stream
      .pipe(csv())
      .on('data', (row) => {
        // Normalize column names (case insensitive)
        const normalizedRow = {};
        Object.keys(row).forEach(key => {
          normalizedRow[key.trim().toLowerCase()] = row[key];
        });
        
        // Map to expected format
        const mappedRow = {
          Name: normalizedRow.name || normalizedRow.fullname || normalizedRow['full name'],
          Email: normalizedRow.email,
          Country: normalizedRow.country,
          ReferralCode: normalizedRow.referralcode || normalizedRow.referral || normalizedRow['referral code'],
          Password: normalizedRow.password
        };
        
        results.push(mappedRow);
      })
      .on('end', () => resolve(results))
      .on('error', reject);
  });
};

/* PARSE EXCEL FILE */
const parseExcel = (buffer) => {
  try {
    const workbook = xlsx.read(buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(worksheet);

    // Normalize and map data
    return data.map(row => {
      const normalizedRow = {};
      Object.keys(row).forEach(key => {
        normalizedRow[key.toString().toLowerCase().trim()] = row[key];
      });

      return {
        Name: normalizedRow.name || normalizedRow.fullname || normalizedRow['full name'] || '',
        Email: normalizedRow.email || '',
        Country: normalizedRow.country || '',
        ReferralCode: normalizedRow.referralcode || normalizedRow.referral || normalizedRow['referral code'] || '',
        Password: normalizedRow.password || ''
      };
    });
  } catch (error) {
    throw new Error('Failed to parse Excel file: ' + error.message);
  }
};

/* GENERATE DEFAULT PASSWORD */
const generateDefaultPassword = async () => {
  const randomChars = Math.random().toString(36).slice(-8);
  return 'User@' + randomChars;
};

/* GET ALL USERS */
exports.getAllUsersAdmin = async (req, res) => {
  try {
    const users = await User.find()
      .select('-password -verificationCode -verificationCodeExpire -resetPasswordToken -resetPasswordExpire')
      .sort({ createdAt: -1 });
    
    res.status(200).json({ 
      success: true, 
      count: users.length, 
      data: users 
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Server error fetching users' 
    });
  }
};